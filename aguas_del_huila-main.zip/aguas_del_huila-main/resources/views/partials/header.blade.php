<meta charset="utf-8" />
<meta name="author" content="Sharrys Tech">
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="robots" content="index, follow">
<meta content="Noticias, medio de comunicación, blog, informacion, servicios público, agua, departamento del Huila" name="keywords">
<meta name="description" content="Aguas del Huila presta servicios públicos de acueducto, alcantarillado y aseo, y ofrece información, noticias y servicios al departamento del Huila.">
<link rel="canonical" href="{{ url()->current() }}">
<meta name="theme-color" content="#0047DC">

<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">

<link rel="preconnect" href="https://fonts.bunny.net">
<link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

<!-- Swiper CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
<!-- Swiper JS -->
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Onest:wght@100..900&display=swap" rel="stylesheet">

<!-- Herramienta de accecibilidad -->
<script src="https://cdn.userway.org/widget.js" data-account="EvnCUKYTJM"></script>

@vite(['resources/css/app.css', 'resources/js/app.js'])
@fluxAppearance
