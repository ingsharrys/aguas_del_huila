<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        @include('partials.header')
        <title>Aguas del Huila - Preguntas Frecuentes</title>
    </head>
    <body class="bg-white">

        @include('partials.navbar')

        <!-- banner inicial -->
        <div class="w-full h-[200px] sm:h-[150px] md:h-[200px] lg:h-[300px] overflow-hidden shadow-lg -top-8 bg-center bg-no-repeat bg-cover relative" style="background-image: url('{{ asset('storage/img/banner_seccion.webp') }}');">
            <div class="absolute inset-0 bg-gradient-to-l from-slate-50/5 to-[#0047DC]/80 flex flex-col justify-center items-center text-white text-center px-16 md:px-32">
                <h2 class="text-3xl lg:text-5xl font-bold mb-2">Preguntas Frecuentes</h2>
                <p class="text-lg">Inicio / Institucional </span class="font-bold"> / Preguntas Frecuentes</span></p>
            </div>
        </div>

        <section class="px-2 lg:px-32 py-8">

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div class="w-full mx-auto">

                    <h3 class="text-2xl font-bold text-[#0047DC]">¿Qué Artículo de la ley 142, elimina la gratuidad en la prestación de Servicios Públicos Domiciliarios?</h3>
                    <div class="prose max-w-none text-justify text-gray-900">
                        El artículo 34 y 98 de la Ley 142 de 1994, en los siguientes términos: El concepto de gratuidad de los servicios públicos ha sido abandonado en la Constitución Política de 1991.</div>
        
                    <h3 class="text-2xl font-bold text-[#0047DC]">¿Cómo puedo reducir el valor de la factura?</h3>
                    <div class="prose max-w-none text-justify text-gray-900">
                    Haciendo un uso y ahorro eficiente del agua, revisar que los sanitarios y las llaves funcionen normalmente, sin fugas.</div>
        
                    <h3 class="text-2xl font-bold text-[#0047DC]">¿Si me llega una factura con un valor fuera de lo normal debo paga?</h3>
                    <div class="prose max-w-none text-justify text-gray-900">
                    Es probable que haya una equivocación en la medición o en el cobro. Llame o acérquese a la Oficina de servicios públicos domiciliarios de Aguas del Huila S.A E.S.P. ubicado en su municipio y su caso tendrá un tratamiento especial para determinar el porqué del incremento.</div>

	
	<h3 class="text-2xl font-bold text-[#0047DC]">¿Dónde puedo expresar mis inquietudes y/o reclamos?</h3>
<div class="prose max-w-none text-justify text-gray-900">
	En la Oficina de servicios públicos domiciliarios de Aguas del Huila S.A E.S.P. ubicado en su municipio</div>
	
	<h3 class="text-2xl font-bold text-[#0047DC]">Tengo un apartamento desocupado y me sigue cobrando el servicio de agua, pese a no haber consumo ¿Qué debo hacer?</h3>
<div class="prose max-w-none text-justify text-gray-900">
	Cuando un predio está desocupado, la AGUAS DEL HUILA S.A E.S.P. está obligada a facturar los cargos fijos de acuerdo con lo establecido en la Ley 142. Sin embargo, existe la posibilidad de solicitar la suspensión temporal del servicio mientras el predio esté desocupado con el fin de no generar los cargos fijos.

Debe acercarse a la oficina en su municipio para presentar la solicitud de suspensión temporal.</div>
	
	<h3 class="text-2xl font-bold text-[#0047DC]"> ¿Qué debo hacer sin no me llega la factura a tiempo?</h3>
<div class="prose max-w-none text-justify text-gray-900">
	Debe acercarse a la Oficina en su municipio y solicitar un Duplicado, el no recibir la factura no lo exonera del pago.</div>
	
	<h3 class="text-2xl font-bold text-[#0047DC]">¿Qué hacer si la Empresas no resuelve el problema o si se niega a recibir la petición, queja, reclamo, denuncias y solicitudes?</h3>
<div class="prose max-w-none text-justify text-gray-900">
	Puede Presentar la queja ante la Superintendencia de Servicios Públicos Domiciliarios.</div>
	
	<h3 class="text-2xl font-bold text-[#0047DC]"> ¿Qué se debe realizar para cambiar el nombre del suscriptor?</h3>
<div class="prose max-w-none text-justify text-gray-900">
	Certificado de Tradición con una vigencia no mayor a tres (3) meses, fotocopia de la Cédula y de la Factura</div>

	
	<h3 class="text-2xl font-bold text-[#0047DC]">¿En dónde puedo pagar cuando me paso de la fecha límite?</h3>
<div class="prose max-w-none text-justify text-gray-900">
	Oficinas de Suchance y los corresponsales bancarios de Bancolombia en su municipio.</div>
	
	<h3 class="text-2xl font-bold text-[#0047DC]">¿Qué pasa si no pago la factura el día que me indica?</h3>
<div class="prose max-w-none text-justify text-gray-900">
	Se generan intereses moratorios y si se llega a la fecha de suspensión presentada en la factura se procederá a suspender, generando un costo adicional de reconexión y suspensión. Su la mora supera los seis meses se genera el corte definitivo.</div>


                </div>

                <div class="w-full mx-auto">

                    <h3 class="text-2xl font-bold text-[#0047DC]">Si me suspenden ¿Qué debo hacer para que reinstalen el servicio?</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Se debe presentar factura de pago en la oficina de su municipio o suscribir un Acuerdo de pago, que debe cumplir, si no tiene la totalidad del valor adeudado. La Empresa no lo exime de suspensión ni genera orden de reconexión. En el siguiente recibo se cobrara el valor generado por la suspensión y reconexión del servicio.</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">¿Cómo solicito cambio de cajilla o medidor?</h3>
    <div class="prose max-w-none text-justify text-gray-900">Se debe dirigir a la Oficina de Aguas del Huila S.A E.S.P. de su municipio para realizar la solicitud respectiva.</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Qué puedo hacer si el uso del servicio que se me cobran no es correcto (cuando la utilización que tiene el predio, bien sea: Residencial, Industrial, Comercial, Oficial o Especial es diferente a lo que aparece en la factura)?</h3>
    <div class="prose max-w-none text-justify text-gray-900">Debe acercarse a la oficina en su municipio, indicando los siguientes datos: código, dirección exacta, nueva clase de uso, anexando el certificado de estratificación socioeconómico. Luego de la visita de verificación realizada por la Empresa el cambio se refleja de manera inmediata en el sistema y la siguiente factura llegará actualizada.</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">¿Cuáles son los requisitos para la solicitud de una conexión domiciliaria de acueducto?</h3>
    <div class="prose max-w-none text-justify text-gray-900">Debe presentar solicitud del servicio anexando: Certificado de Tradición vigente, Fotocopia de la cédula, Certificado de estratificación, certificado que el predio no se encuentra en zona de alto riesgo.</div>

	
	<h3 class="text-2xl font-bold text-[#0047DC]">Por qué me cobran barrido si no me barren frente a mi casa?</h3>
    <div class="prose max-w-none text-justify text-gray-900"> El servicio de barrido que se cobra en la factura, corresponde a las áreas públicas del lugar donde habita (como parques, calles, espacios públicos), pero no al barrido frente a la casa o de la cuadra. Es decir, un servicio que pagamos todos los usuarios del municipio para contribuir con la limpieza de las principales vías y parques de la ciudad.</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">¿Qué diferencia hay entre suscriptor y usuario?</h3>
    <div class="prose max-w-none text-justify text-gray-900">Suscriptor es la persona natural o jurídica con la cual se ha celebrado un contrato de condiciones uniformes de servicios públicos.

Usuario es toda persona natural o jurídica que se beneficia con la prestación de un servicio público, bien como propietario del inmueble en donde este se presta, o como receptor directo del servicio. A este último usuario se denomina también consumidor.</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">¿Qué es un contrato de prestación de servicios públicos?</h3>
    <div class="prose max-w-none text-justify text-gray-900">Según la Ley 142 de 1994 es un contrato uniforme, consensual, en virtud del cual una empresa de servicios públicos los presta a un usuario a cambio de un precio en dinero, de acuerdo con estipulaciones que han sido definidas por ella para ofrecerlas a muchos usuarios no determinados.</div>

	<h3 class="text-2xl font-bold text-[#0047DC]"> ¿Quiénes son partes en el contrato de servicios públicos?</h3>
    <div class="prose max-w-none text-justify text-gray-900">Son partes del contrato la empresa de servicios públicos, el suscriptor y/o usuario.
El propietario o poseedor del inmueble, el suscriptor y los usuarios del servicio son solidarios en sus obligaciones y derechos en el contrato de servicios públicos.

Es decir, tanto el propietario, el poseedor, el suscritor y el usuario, se entienden obligados con la empresa de servicios públicos domiciliarios y responderán cada uno o entre todos por la totalidad de las obligaciones derivadas del contrato.</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">¿Si el inmueble es vendido o cambia de propietario que pasa con el contrato?</h3>
    <div class="prose max-w-none text-justify text-gray-900">Según la Ley 142 de 1994 en la enajenación de bienes raíces urbanos se entiende que hay cesión de todos los contratos de servicios públicos domiciliarios, salvo que las partes acuerden otra cosa y esta cesión operará de pleno derecho.

Es decir, si el inmueble cambia de propietario se entenderá que el nuevo propietario reemplaza al anterior en el contrato de servicios públicos en las mismas condiciones sin necesidad de que las partes lo acuerden verbalmente o por escrito.</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">¿Desde qué momento la empresa de servicios públicos está facultada para suspender el servicio?</h3>
    <div class="prose max-w-none text-justify text-gray-900">Si el usuario o suscriptor incumple su obligación de pagar oportunamente los servicios facturados dentro del término previsto en el contrato, el cual no excederá dos períodos consecutivos de facturación, la empresa de servicios públicos estará en la obligación de suspender el servicio.</div>

                </div>



            </div>

        </section>

        @include('partials.footer')

    </body>
</html>
