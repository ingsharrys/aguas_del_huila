<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        @include('partials.header')
        <title>Aguas del Huila - Glosario</title>
    </head>
    <body class="bg-white">

        @include('partials.navbar')

        <!-- banner inicial -->
        <div class="w-full h-[200px] sm:h-[150px] md:h-[200px] lg:h-[300px] overflow-hidden shadow-lg -top-8 bg-center bg-no-repeat bg-cover relative" style="background-image: url('{{ asset('storage/img/banner_seccion.webp') }}');">
            <div class="absolute inset-0 bg-gradient-to-l from-slate-50/5 to-[#0047DC]/80 flex flex-col justify-center items-center text-white text-center px-16 md:px-32">
                <h2 class="text-3xl lg:text-5xl font-bold mb-2">Glosario</h2>
                <p class="text-lg">Inicio / Institucional </span class="font-bold"> / Glosario</span></p>
            </div>
        </div>

        <section class="px-2 lg:px-32 py-8">

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div class="w-full mx-auto">

                    <h3 class="text-2xl font-bold text-[#0047DC]">Acometida</h3>
                    <div class="prose max-w-none text-justify text-gray-900">
                        Derivación de la red local del servicio respectivo que llega hasta el registro de corte del inmueble. En edificios de propiedad horizontal o condominios, la acometida llega hasta el registro de corte general. Para el caso de alcantarillado la acometida es la derivación que parte de la caja de inspección y llega hasta el colector de la red local.</div>
        
                    <h3 class="text-2xl font-bold text-[#0047DC]">Actividad complementaria de un servicio público</h3>
                    <div class="prose max-w-none text-justify text-gray-900">
                    Son las actividades a las que también se aplica esta Ley, según la precisión que se hace adelante, al definir cada servicio público. Cuando en esta Ley se mencionen los servicios públicos, sin hacer precisión especial, se entienden incluidas tales actividades.</div>
        
                    <h3 class="text-2xl font-bold text-[#0047DC]">Aforo</h3>
                    <div class="prose max-w-none text-justify text-gray-900">
                    Es el resultado de las mediciones puntuales, que realiza un aforador debidamente autorizado por la persona prestadora, respecto de la cantidad de residuos sólidos que produce y presenta un usuario de manera individual o conjunta al prestador del servicio de aseo.</div>

	
	<h3 class="text-2xl font-bold text-[#0047DC]">Aforo extraordinario de aseo para multiusuarios</h3>
<div class="prose max-w-none text-justify text-gray-900">
	Es el resultado de las mediciones puntuales realizadas por la persona prestadora del servicio público de aseo, de oficio o a petición del multiusuario, cuando alguno de ellos considere que ha variado la cantidad de residuos producidos con respecto al aforo vigente.</div>
	
	<h3 class="text-2xl font-bold text-[#0047DC]">Aforo ordinario de aseo para multiusuarios</h3>
<div class="prose max-w-none text-justify text-gray-900">
	Es el resultado de las mediciones puntuales realizadas por la persona prestadora del servicio público de aseo, para categorizar y cobrar como multiusuarios a aquellos suscriptores que optaron por ésta opción tarifaria.</div>
	
	<h3 class="text-2xl font-bold text-[#0047DC]">Aforo permanente de aseo</h3>
<div class="prose max-w-none text-justify text-gray-900">
	Es el que realiza la persona prestadora del servicio público de aseo a los suscriptores grandes productores o pequeños productores de residuos sólidos, cuando efectúa la recolección de los residuos presentados por el usuario.</div>
	
	<h3 class="text-2xl font-bold text-[#0047DC]">Almacenamiento de residuos sólidos</h3>
<div class="prose max-w-none text-justify text-gray-900">
	Es la acción del usuario de guardar temporalmente los residuos sólidos en depósitos, recipientes o cajas de almacenamiento, retornables o desechables, para su recolección por la persona prestadora con fines de aprovechamiento o de disposición final.</div>
	
	<h3 class="text-2xl font-bold text-[#0047DC]">Aprovechamiento</h3>
<div class="prose max-w-none text-justify text-gray-900">
	Es la actividad complementaria del servicio público de aseo que comprende la recolección de residuos aprovechables separados en la fuente por los usuarios, el transporte selectivo hasta la estación de clasificación y aprovechamiento o hasta la planta de aprovechamiento, así como su clasificación y pesaje.</div>

	
	<h3 class="text-2xl font-bold text-[#0047DC]">Área de prestación de servicio</h3>
<div class="prose max-w-none text-justify text-gray-900">
	Corresponde a la zona geográfica del municipio o distrito debidamente delimitada donde la persona prestadora ofrece y presta el servicio de aseo. Esta deberá consignarse en el contrato de condiciones uniformes.</div>
	
	<h3 class="text-2xl font-bold text-[#0047DC]">Área pública</h3>
<div class="prose max-w-none text-justify text-gray-900">
	Es aquella destinada al uso, recreo o tránsito público, como parques, plazas, plazoletas y playas salvo aquellas con restricciones de acceso.</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Accesorios</h3>
<div class="prose max-w-none text-justify text-gray-900">
	Elementos componentes de un sistema de tuberías, diferentes de las tuberías en sí, tales como uniones, codos, tés etc.</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Acometida </h3>
    <div class="prose max-w-none text-justify text-gray-900">(Artículo 14.1 Ley 142 de 1994)
	Derivación de la red local que llega hasta el registro de corte del inmueble
	Permite al usuario abastecerse del servicio público y debe ser pagada por él
	En edificios de propiedad horizontal, la acometida llega hasta el registro de corte general</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Acometida clandestina o fraudulenta</h3>
    <div class="prose max-w-none text-justify text-gray-900">(Decreto 302 de 2000)
	Acometida o derivación de acueducto o alcantarillado no autorizada por la entidad prestadora del servicio</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Acometida de acueducto</h3>
    <div class="prose max-w-none text-justify text-gray-900">(Decreto 302 de 2000)
	Derivación de la red local de acueducto que se conecta al registro de corte en el inmueble
	En edificios de propiedad horizontal o condominios la acometida llega hasta el registro de corte general</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Acometida de alcantarillado</h3>
    <div class="prose max-w-none text-justify text-gray-900">(Decreto 302 de 2000)
	Derivación que parte de la caja de inspección y llega hasta el colector de la red local</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Acueducto</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Conjunto de obras, equipos y materiales utilizados para la captación, aducción, conducción, tratamiento y distribución del agua potable para consumo humano.</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Acuífero</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Formación geológica o grupo de formaciones que contiene agua y que permite su movimiento a través de sus poros bajo la acción de la aceleración de la gravedad o de diferencias de presión</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Adopción de la estratificación</h3>
    <div class="prose max-w-none text-justify text-gray-900"> (Artículo 3 Decreto 1538 de 1996)
	Acto mediante el cual el alcalde o el gobernador expide el decreto por medio del cual, como resultado de la aplicación de las metodologías, se asignan los estratos a los inmuebles residenciales por el término de cinco (5) años</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Aducción</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Componente a través del cual se transporta agua cruda, ya sea a flujo libre o a presión</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Afluente</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Agua, agua residual u otro líquido que ingrese a un reservorio o a algún proceso de tratamiento</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Aforo </h3>
    <div class="prose max-w-none text-justify text-gray-900">(Resolución CRA 14 de 1997)
	Procedimiento por el cual se mide o estima la cantidad de agua que normalmente utiliza un usuario
	Se emplea cuando el usuario no tiene instrumento de medición idóneo
	Igualmente se emplea este término para estimar la cantidad de basura que produce un usuario</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Aforo de agua</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Es el procedimiento por medio del cual se mide o estima la cantidad de agua que normalmente utiliza un usuario</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Aforador de aseo</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Es la persona debidamente autorizada por la persona prestadora del servicio público domiciliario de aseo, para realizar los aforos de producción de residuos sólidos</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Aforo extraordinario de aseo</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Es el realizado por la persona prestadora del servicio público domiciliario de aseo, de oficio o a petición del usuario, cuando alguno de ellos encuentre que ha variado la cantidad de residuos producidos durante la vigencia del aforo ordinario, o dentro de los procedimientos de reclamación y/o recurso</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Aforo ordinario de aseo</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Es el realizado de oficio por la persona prestadora del servicio público domiciliario de aseo, para incorporar nuevos usuarios o actualizar el aforo correspondiente al periodo anterior</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Aforo permanente de aseo</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Es el que decide realizar la persona prestadora del servicio público domiciliario de aseo cada vez que se les preste el servicio de recolección a los usuarios grandes productores</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Aforo residuos sólidos</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Determinación puntual de la cantidad de residuos sólidos presentados para la recolección por un usuario determinado</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Agua cruda</h3>
    <div class="prose max-w-none text-justify text-gray-900"> (Artículo 1 Decreto 475 de 1998)
	Agua que no ha sido sometida a proceso de tratamiento</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Agua para consumo humano</h3>
    <div class="prose max-w-none text-justify text-gray-900"> (Artículo 1 Decreto 475 de 1998)
	Es aquella que se utiliza en bebida directa y preparación de alimentos para consumo</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Agua potable</h3>
    <div class="prose max-w-none text-justify text-gray-900"> (Artículo 1 Decreto 475 de 1998)
	Aquella que por reunir los requisitos organolépticos (olor, sabor y percepción visual), físicos, químicos y microbiológicos, puede ser consumida por la población humana sin producir efectos adversos a la salud</div>



                </div>

                <div class="w-full mx-auto">

                    <h3 class="text-2xl font-bold text-[#0047DC]">Aguas lluvias</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Aguas provenientes de la precipitación pluvial</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Aguas residuales</h3>
    <div class="prose max-w-none text-justify text-gray-900"> (o de alcantarillado)
	Desechos líquidos provenientes de residencias, edificios, instituciones, fábricas, industrias y demás inmuebles</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Aguas servidas</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Aguas de desecho provenientes de lavamanos, tinas de baño, duchas, lavaplatos, y otros artefactos que no descargan materias fecales</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Aireación</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Proceso en el que se produce un contacto entre el aire y el agua con el objetivo de oxigenarla o de excluir gases o sustancias volátiles
	2
	Proceso de transferencia de masa, generalmente referido a la transferencia de oxígeno al agua por medios naturales (flujo natural, cascadas, etc.) o artificiales (agitación mecánica o difusión de aire comprimido)
	Véase también Tanque de aireación</div>

	
	<h3 class="text-2xl font-bold text-[#0047DC]">Ajuste gradual o gradualidad tarifaria</h3>
    <div class="prose max-w-none text-justify text-gray-900"> (Resolución CRA 22 de 1996)
	Ajuste progresivo en las tarifas de tal manera que en cada año se avance en el logro del objetivo de alcanzar las tarifas resultantes de la aplicación de las metodologías definidas por la Comisión de Regulación de Agua Potable y Saneamiento Básico</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Alcantarillado de aguas combinadas</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Sistema compuesto por todas las instalaciones destinadas a la recolección y transporte, tanto de las aguas residuales como de las aguas lluvias</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Alcantarillado de aguas lluvias</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Sistema compuesto por todas las instalaciones destinadas a la recolección y transporte de aguas lluvias</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Alcantarillado de aguas residuales</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Sistema compuesto por todas las instalaciones destinadas a la recolección y transporte de las aguas residuales domésticas y/o industriales</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Alcantarillado separado</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Sistema constituido por un alcantarillado de aguas residuales y otro de aguas lluvias que recolectan en forma independiente en un mismo sector</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Alcantarillado</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Conjunto de obras para la recolección, conducción y disposición final de las aguas residuales o de las aguas lluvias</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Aliviadero</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Estructura diseñada en colectores combinados, con el propósito de separar los caudales que exceden la capacidad del sistema y conducirlos a un sistema de drenaje de agua lluvia</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Almacenamiento </h3>
    <div class="prose max-w-none text-justify text-gray-900">(acueducto)
	Acción destinada a almacenar un determinado volumen de agua para cubrir los picos horarios y la demanda contra incendios</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Almacenamiento de residuos sólidos </h3>
    <div class="prose max-w-none text-justify text-gray-900">(Capítulo F1 Resolución MDE 0822 de 1998)
	Acumulación o depósito temporal, en recipientes o lugares, de la basura y residuos sólidos de un generador o una comunidad, para su posterior recolección, aprovechamiento, transformación, comercialización o disposición final</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Almacenamiento domiciliario</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Acción del generador de depositar temporalmente los residuos retenidos en los condominios, edificios multifamiliares, viviendas, etc.</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Almacenamiento no domiciliario</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Acción del generador de depositar temporalmente los residuos sólidos retenidos en centros comerciales, edificios públicos, edificios privados, bancos, instituciones de interés social, centros de recreación, etc.</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Análisis físico químico del agua</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Pruebas de laboratorio que se efectúan a una muestra para determinar sus características físicas, químicas o ambas

	Análisis microbiológico del agua
	Pruebas de laboratorio que se efectúan una muestra para determinar la presencia o ausencia, tipo y cantidad de microorganismos</div>

	
	<h3 class="text-2xl font-bold text-[#0047DC]">Análisis organoléptico del agua</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Se refiere a olor, sabor y percepción visual de sustancias y materiales flotantes y/o suspendidos en el agua

	Año base.
	Entiéndase como "año" el periodo de doce meses, el cual puede coincidir o no con una vigencia fiscal, que es utilizado por la persona prestadora, con el fin de hacer las comparaciones y verificaciones que corresponda, para calcular los costos de prestación del servicio, tomando como base, el más cercano al momento del cálculo, del cual se tenga información completa y ajustada al comportamiento típico de sus costos
	o el que defina la Comisión
	Las personas prestadoras que tengan menos de un año de operación, podrán establecer los costos del año base, proyectando los costos del servicio, con base en la información del tiempo durante el cual hayan operado y teniendo en cuenta el diseño que deben realizar para la prestación del servicio
	En este caso, deben informar a la Comisión de Regulación los supuestos empleados</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Aplicación de la estratificación</h3>
    <div class="prose max-w-none text-justify text-gray-900"> (Artículo 3 Decreto 1538 de 1996)
	Fase en la cual las entidades prestadoras de servicios públicos domiciliarios en el municipio o distrito empiezan a facturar el cobro de éstos con base en las estratificaciones adoptadas</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Aporte solidario</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Véase Contribución</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">APORTES DE CONEXIÓN</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Son los pagos que realiza el suscriptor o suscriptor potencial para conectar un inmueble por primera vez, o para cambiar el diámetro dela acometida, al sistema o red existente
	Están compuestos por los Costos Directos de Conexión y por los Cargos por Expansión del Sistema

	Aprovechamiento (Capítulo F1 Resolución MDE 0822 de 1998)
	Proceso mediante el cual, a través de un manejo integral de los residuos sólidos, los materiales recuperados se reincorporan al ciclo económico y productivo en forma eficiente, por medio de la reutilización, el reciclaje, la incineración con fines degeneración de energía, el compostaje
	o cualquier otra modalidad que con lleve beneficios sanitarios, ambientales o económicos</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Áreas de servicio exclusivo</h3>
    <div class="prose max-w-none text-justify text-gray-900"> (Resolución CRA 11 de 1996 y artículo 40 Ley142 de 1994)
	Zonas otorgadas por las entidades territoriales competentes a una empresa de servicios públicos de acueducto, alcantarillado y aseo, mediante licitación pública, en la cual ninguna otra empresa puede ofrecer los servicios objeto del contrato, durante un tiempo determinado
	Estas zonas son determinadas con el fin de que los servicios públicos se puedan extender a las personas de menores recursos económicos</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Asentamiento subnormal</h3>
    <div class="prose max-w-none text-justify text-gray-900">
	Es aquel cuya infraestructura de servicios públicos domiciliarios presenta serias deficiencias por no estar integrada totalmente a la estructura formal urbana</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Asentamiento subnormal</h3>
    <div class="prose max-w-none text-justify text-gray-900"> (Decreto 302 de 2000)
	Es aquel cuya infraestructura de servicios públicos domiciliarios presenta serias deficiencias por no estar integrada totalmente a la estructura formal urbana y en el cual las familias viven en condiciones de pobreza crítica
	Usualmente se clasifican en el Estrato 1</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Auditoría externa </h3>
    <div class="prose max-w-none text-justify text-gray-900">(Artículo 51 Ley 142 de 1994)
	Todas las empresas de servicios públicos están obligadas a contratar una auditoría externa de gestión y resultados con personas privadas especializadas
	La auditoría externa obrará en función de los intereses de la empresa y de sus negocios y del beneficio que reciben los usuarios
	Está obligada a informar a la Superintendencia las situaciones que pongan en peligro la viabilidad financiera, las fallas en el control interno y las apreciaciones de evaluación sobre el manejo de la empresa
	Deberá elaborar, al menos una vez al año, una evaluación del manejo de la empresa</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Autoridad ambiental </h3>
    <div class="prose max-w-none text-justify text-gray-900">(Artículo 1 Decreto 475 de 1998)
	Es la encargada de la vigilancia, conservación, protección, ordenamiento, manejo, uso, aprovechamiento y control de los recursos naturales renovables y del medio ambiente</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">Autoridad sanitaria</h3>
    <div class="prose max-w-none text-justify text-gray-900"> (Artículo 1 Decreto 475 de 1998)
	Es la entidad competente del sistema general de seguridad social que ejerce funciones de vigilancia de los sistemas de suministro de agua en cumplimiento de las normas, disposiciones y criterios legales, así como los demás aspectos que tengan relación con la calidad del agua para consumo human</div>

	<h3 class="text-2xl font-bold text-[#0047DC]">PDA: Plan Departamental de Agua</h3>
    <div class="prose max-w-none text-justify text-gray-900">

	Ventanilla única: Lugar donde se radican los proyectos en el Ministerio de vivienda Ciudad y Territorio para su viabilidad</div>

                </div>



            </div>

        </section>

        @include('partials.footer')

    </body>
</html>
