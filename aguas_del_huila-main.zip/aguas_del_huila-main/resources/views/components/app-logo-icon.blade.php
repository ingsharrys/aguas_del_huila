<img src="{{ asset('/storage/img/logo/logo_aguas_huila.png') }}" alt="Logo" class="h-8 w-auto" {{ $attributes }}>
